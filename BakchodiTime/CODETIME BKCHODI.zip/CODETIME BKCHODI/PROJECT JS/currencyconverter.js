// currencyConverter.js
const currencyRates = {
    USD: 1,
    EUR: 0.82, // Sample conversion rates
    GBP: 0.73,
    JPY: 109.52
};

function convertCurrency(amount, fromCurrency, toCurrency) {
    if (!currencyRates[fromCurrency] || !currencyRates[toCurrency]) {
        return "Currency not supported.";
    }

    const conversionRate = currencyRates[toCurrency] / currencyRates[fromCurrency];
    const convertedAmount = amount * conversionRate;
    return convertedAmount.toFixed(2); // Round converted amount to two decimal places
}

// Example usage
console.log("BMI:", calculateBMI(70, 170)); // Example: BMI for weight 70 kg and height 170 cm
console.log("Converted amount:", convertCurrency(100, 'USD', 'EUR')); // Example: convert $100 to Euro
