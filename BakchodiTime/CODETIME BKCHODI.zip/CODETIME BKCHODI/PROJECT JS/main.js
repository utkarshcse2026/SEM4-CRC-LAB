// main.js
const { calculateBMI } = require('bmiCalculator.js');
const { convertCurrency } = require('currencyConverter.js');

// Example usage
console.log("BMI:", calculateBMI(70, 170)); // Example: BMI for weight 70 kg and height 170 cm
console.log("Converted amount:", convertCurrency(100, 'USD', 'EUR')); // Example: convert $100 to Euro
