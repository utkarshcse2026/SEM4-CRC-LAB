// bmiCalculator.js
function calculateBMI(weight, height) {
    if (weight <= 0 || height <= 0) {
        return "Invalid input. Weight and height must be greater than zero.";
    }
    
    // BMI formula: weight (kg) / (height (m) * height (m))
    const bmi = weight / ((height / 100) * (height / 100));
    return bmi.toFixed(2); // Round BMI to two decimal places
}

